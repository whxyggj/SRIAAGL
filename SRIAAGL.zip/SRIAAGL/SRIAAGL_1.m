function [A,S,F,obj] = SRIAAGL_1(X_all,gt,numanchor,lambda,idx)
% m      : the number of anchor. 
% the size of Z is m*n.
% X      : dv*n_vo 
% Y      : n*1
%% initialize
maxIter = 100; % the number of iterations
m = numanchor;
numclass = length(unique(gt));
d_v = size(X_all,1);
%numview = length(X);
n = size(gt,1);
%missingindex = constructA(ind);%
idx_o = idx ==1;
X=X_all(:,idx_o);
n_vo=size(X,2);
%idx_u = idx ==0;

%% initialize 


A = zeros(d_v,m); 
Z = zeros(m,n_vo);% m  * n
S = zeros(m,n);

Fu = zeros(n_vo,numclass);
Fv = zeros(m,numclass);

Du = sparse(ones(n_vo,n_vo));
Dv = sparse(ones(m,m));

Isconverg = 0;
iter = 1;
epson = 10e-5;


while(Isconverg == 0)
        %fprintf('----processing iter %d--------\n', iter);
 

        %% optimize A_1
        temp_A= X*Z';
        [U_A,~,V_A] = svd(temp_A,'econ');
        A = U_A*V_A';


        %% optimize Z_1
        
        FuDu= Fu.*diag(Du);
        FvDv= Fv.*diag(Dv);

        dist = L2_distance_1(FuDu',FvDv');

        temp_Z=A'*X-lambda*dist'/2;

        for lie=1:n_vo
            Z(:, lie) = EProjSimplex_new(temp_Z(:,lie));
        end


        %% optimize F
        
        % Calculate Du^{-0.5} and Dv^{-0.5}
        du = sum(Z);  
        Du = spdiags(1./sqrt(du),0,n_vo,n_vo);
        dv = max(sum(Z,2),1e-5);  
        Dv = spdiags(1./sqrt(dv),0,m,m);
        
        DZD = Du*sparse(Z')*Dv;
        
        [U,~,V] = svds(DZD,numclass);
        
        Fu = sqrt(2)*U/2;
        Fv = sqrt(2)*V/2;
    
        obj(iter) = sum(sum((X-A*Z).^2))- lambda* trace(Fu'*DZD*Fv);
        if (iter>2) && (abs((obj(iter)-obj(iter-1))/(obj(iter)))<epson  || iter>maxIter)
            Isconverg  =1;
        end
            iter = iter + 1;
end

S(:,idx_o)=Z;
F=[Fu;Fv];

end
