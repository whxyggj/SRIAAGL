

clear;
clc;

path = '../';
addpath(path);

resultdir1 = 'Results/';
if (~exist('Results', 'file'))
    mkdir('Results');
    addpath(genpath('Results/'));
end

resultdir2 = 'totalResults/';
if (~exist('totalResults', 'file'))
    mkdir('totalResults');
    addpath(genpath('totalResults/'));
end

%datadir='Incomplete/';
%datadir='/home1/baichengpan/IIMVC/Incomplete_datasets/';
datadir='E:/[3] Incomplete Multi-view Clustering/Incomplete_datasets/';

%%dataname={'MSRCV1_3v', 'yale_mtv_2', 'ORL','COIL20-3v','handwritten_3v'};
%dataname = {'Caltech101-7','Caltech101-20','BDGP_fea'};
dataname = {'my_NGs'};
%dataname={'my_3sources','my_100leaves','my_ALOI-100','my_BBC4view','my_BBCsport'};
%dataname={'my_Caltech101-all','my_CCV','my_Citeseer','my_COIL20','my_EYaleB10'};
%dataname={'my_Handwritten','my_Hdigit','my_Mfeat','my_MSRCV1','my_NGs'};
%dataname={'my_NUS','my_ORL_mtv','my_prokaryotic','my_reuters_5view','my_Scene-15'};
%dataname={'my_SUNRGBD','my_Texas','my_UCI3view','my_WebKB','my_WebKB_2view'};
%dataname={'my_webKB_cornell','my_Wiki_fea','my_WikipediaArticles','my_Wisconsin','my_Youtube'};

numdata = length(dataname); % number of the test datasets
%numname = {'_Per0.1', '_Per0.2', '_Per0.3', '_Per0.4','_Per0.5', '_Per0.6', '_Per0.7', '_Per0.8', '_Per0.9'};
%
numname = {'_Per0.5'};

for idata = 1 : numdata
    ResBest = zeros(length(numname), 8);
    ResStd = zeros(length(numname), 8);
    for dataIndex =  1:1:length(numname)
%     for dataIndex = 1 : 1
        datafile = [datadir, cell2mat(dataname(idata)), cell2mat(numname(dataIndex)), '.mat'];
        load(datafile);
        %data preparation...
        gt = truelabel{1};
        cls_num = length(unique(gt));
        k= cls_num;
        tic;
        %%[X1, ind] = DataPreparing(data, index);
        [X1, ind] = findindex(data, index); % ind observed ==1, missing == 0

        
        time1 = toc;
        maxAcc = 0;
        %         TempLambda1 = 0.01;
        TempLambda1 = [0.0001,0.001,0.01,0.1,1,10,100,1000];
        TempLambda2 = [0.0001,0.001,0.01,0.1,1,10,100,1000];
        %TempLambda1 = 10;
        %TempLambda2 = 10;
        anchors =1;
           
        ACC = zeros(length(TempLambda1),length(TempLambda2));
        NMI = zeros(length(TempLambda1), length(TempLambda2));
        Purity = zeros(length(TempLambda1), length(TempLambda2));
        idx = 1;
        for LambdaIndex1 = 1 : length(TempLambda1)
            lambda1 = TempLambda1(LambdaIndex1);
            for LambdaIndex2 = 1 : length(TempLambda2)
                lambda2 = TempLambda2(LambdaIndex2);
                disp([char(dataname(idata)), char(numname(dataIndex)), '-l1=', num2str(lambda1), '-l2=', num2str(lambda2)]);
                tic;
                [A,S,obj] = SRIAAGL(X1,gt,anchors*k,lambda1,lambda2,ind);
                
                [UU,~,~]=svd(S{max(size(S,1),size(S,2))}','econ');

                time2 = toc;
                stream = RandStream.getGlobalStream;
                reset(stream);
                MAXiter = 1000; % Maximum number of iterations for KMeans
                REPlic = 20; % Number of replications for KMeans
                tic;
                for rep = 1 : 20
                    pY = kmeans(UU, cls_num, 'maxiter', MAXiter, 'replicates', REPlic, 'emptyaction', 'singleton');
                    res(rep, : ) = Clustering8Measure(gt, pY);
                end
                time3 = toc;
                runtime(idx) = time1 + time2 + time3/20;
                disp(['runtime:', num2str(runtime(idx))])
                idx = idx + 1;
                tempResBest(dataIndex, : ) = mean(res);
                tempResStd(dataIndex, : ) = std(res);
                ACC(LambdaIndex1, LambdaIndex2) = tempResBest(dataIndex, 1);
                NMI(LambdaIndex1, LambdaIndex2) = tempResBest(dataIndex, 2);
                Purity(LambdaIndex1, LambdaIndex2) = tempResBest(dataIndex, 3);
                save([resultdir1, char(dataname(idata)), char(numname(dataIndex)), '-l1=', num2str(lambda1), '-l2=', num2str(lambda2), ...
                    '-acc=', num2str(tempResBest(dataIndex, 1)), '_result.mat'], 'tempResBest', 'tempResStd');
                for tempIndex = 1 : 8
                    if tempResBest(dataIndex, tempIndex) > ResBest(dataIndex, tempIndex)
                        if tempIndex == 1
                            newU = UU;
                        end
                        ResBest(dataIndex, tempIndex) = tempResBest(dataIndex, tempIndex);
                        ResStd(dataIndex, tempIndex) = tempResStd(dataIndex, tempIndex);
                    end
                end
            end
        end
        aRuntime = mean(runtime);
        PResBest = ResBest(dataIndex, :);
        PResStd = ResStd(dataIndex, :);
        save([resultdir2, char(dataname(idata)), char(numname(dataIndex)), 'ACC_', num2str(max(ACC(:))), '_result.mat'], 'ACC', 'newU', 'NMI', 'Purity', 'aRuntime', 'PResBest', 'PResStd');
    end
    save([resultdir2, char(dataname(idata)), '_result.mat'], 'ResBest', 'ResStd');
end
