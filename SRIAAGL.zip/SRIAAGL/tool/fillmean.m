function [X1, ind] = fillmean(data, index)
%FINDINDEX Summary of this function goes here
%   Detailed explanation goes here
[numofview,~] = size(data);
[~,numofsample] = size(data{1});

X1 = cell(numofview,1);

ind = zeros(numofsample,numofview);
for i=1:numofview
    [d,~]=size(data{i});
    ind(index{i}, i) = 1;
    origin = data{i};
    origin_valid=origin(:,ind(:,i)==1);
    mean_vec=mean(origin_valid,2);
    origin(:, ind(:,i)==0) = repmat(mean_vec, 1, sum(ind(:,i)==0));
    X1{i} = NormalizeData(origin);    
end




end

