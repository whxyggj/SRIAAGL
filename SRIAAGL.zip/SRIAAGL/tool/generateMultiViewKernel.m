function K = generateMultiViewKernel(X_views, nClusters, kernelType)
    % X_views: 一个 cell 数组，每个元素是一个视图的数据矩阵
    % nClusters: 聚类簇数
    % kernelType: 核函数类型，例如 'rbf', 'poly', 'linear'
    

nViews = length(X_views);
nSamples = size(X_views{1}, 2); % 假设所有视图的样本数相同

% 初始化核矩阵张量
K = zeros(nSamples, nClusters, nViews);

for v = 1:nViews
    % 获取当前视图的数据
    X = X_views{v};
    
    % 计算核矩阵
    switch kernelType
        case 'rbf'
            gamma = 0.1; % RBF核参数
            kernelMatrix = rbfKernel(X', gamma);
        case 'poly'
            degree = 3; % 多项式核参数
            kernelMatrix = polyKernel(X', degree);
        case 'linear'
            kernelMatrix = linearKernel(X');
        otherwise
            error('Unsupported kernel type');
    end
    
    % 特征提取或降维到 nClusters 维度（例如使用PCA或其他方法）
    [coeff, ~] = pca(kernelMatrix);
    reducedKernelMatrix = kernelMatrix * coeff(:, 1:nClusters);
    
    % 存储结果到张量
    K(:, :, v) = reducedKernelMatrix;
end
end

function K = linearKernel(X)
    K = X * X';
end

function K = polyKernel(X, degree)
    K = (X * X' + 1).^degree;
end

function K = rbfKernel(X, gamma)
    sqDist = pdist2(X, X, 'squaredeuclidean');
    K = exp(-gamma * sqDist);
end