function [A,S,obj] = SRIAAGL(X,gt,numanchor,lambda,alpha,ind)
%% ||A-AZ||_{F}^{2}+||ZQ+EP-S||_{F}^{2}+\alpha||SM-SM||_{F}^{2}+\lambdaTr(FLF)
% X         d_v x n_vo
% A         d x n_vo
% Z         m x n_vo
m = numanchor;
numclass = length(unique(gt));
numview = length(X);
numsample = size(gt,1);
obj=cell(numview,1);

for v =1:numview
    A{v} = zeros(size(X{v},1),m); 
    S{v} = zeros(m,numsample);% m  * n     
    %F{v} = zeros(m+numsample,numclass);
end

ind_all=0;

for t = 1:numview
    if t==1
        [A{1},S{1},~,obj{1}] = SRIAAGL_1(X{1},gt,numanchor,lambda,ind(:,1));
    else
        ind_all=ind_all+ind(:,t-1); %% the index ==1 of all previus views
        ind_all(ind_all>1)=1;
        [A{t},S{t},~,obj{t}] = SRIAAGL_t(X{t},gt,S{t-1},numanchor,lambda,alpha,ind(:,t),ind_all);
    end


end