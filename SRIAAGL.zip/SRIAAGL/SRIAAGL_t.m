function [A,S,F,obj] = SRIAAGL_t(X_all,gt,S_last,numanchor,lambda,alpha,idx,ind_all)
% m      : the number of anchor. 
% the size of Z is m*n.
% X      : dv*n_vo 
% Y      : n*1
%% initialize
maxIter = 100; % the number of iterations
m = numanchor;
numclass = length(unique(gt));
idx_o = idx ==1;
idx_u = idx ==0;
X=X_all(:,idx_o);
d_v = size(X_all,1);
n_vo = size(X,2);

%numview = length(X);
n = size(gt,1);
%missingindex = constructA(ind);%
n_vu=n-n_vo;
%% initialize 




idx_a= ind_all==1;
idx_b= ind_all==0;

n_va=sum(ind_all);
n_vb=sum(~ind_all);


A = zeros(d_v,m); 
Z = zeros(m,n_vo);
S = zeros(m,n);
S_nva = zeros(m,n_va);
S_nvb = zeros(m,n_vb);
B = zeros(m,n);
E = zeros(m,n_vu);

Fu = zeros(n_va,numclass);
Fv = zeros(2*m,numclass);

Du = sparse(ones(n_va,n_va));
Dv = sparse(ones(2*m,2*m));

SA_last=S(:,idx_a);

Isconverg = 0;
iter = 1;
epson = 10e-5;


while(Isconverg == 0)
        %fprintf('----processing iter %d--------\n', iter);
 

        %% optimize A_t
        temp_A= X*Z';
        [U_A,~,V_A] = svd(temp_A,'econ');  
        A = U_A*V_A';

        %% optimize E_t
        
        S_E= S(:,idx_u);

        for lie=1:n_vu
            E(:, lie) = EProjSimplex_new(S_E(:,lie));
        end


        %% optimize Z_t

        S_Z=S(:,idx_o);

        temp_Z=0.5*(S_Z+A'*X);

        for lie=1:n_vo
            Z(:, lie) = EProjSimplex_new(temp_Z(:,lie));
        end





        %% optimize S in n-nva


        B(:,idx_o)=Z;
        B(:,idx_u)=E;

        B_nvb=B(:,idx_b);


        for lie=1:n_vb
            S_nvb(:, lie) = EProjSimplex_new(B_nvb(:,lie));
        end

        S(:,idx_b)=S_nvb;

        %% optimize S in nva

        B_nva=B(:,idx_a);
        S_last_nva= S_last(:,idx_a);
        Fvv=Fv(1:m,:);
        Dvv=Dv(1:m,1:m);

        
        FuDu= Fu.*diag(Du);
        FvDv= Fvv.*diag(Dvv);

        dist = L2_distance_1(FvDv',FuDu');

        temp_S=(B_nva+alpha*S_last_nva-0.5*lambda*dist)/(alpha+1);

        for lie=1:n_va
            S_nva(:, lie) = EProjSimplex_new(temp_S(:,lie));
        end

        S(:,idx_a)=S_nva;

        %% optimize F
        
        SA=S(:,idx_a);
        

        G=[SA;SA_last];
        
        % Calculate Du^{-0.5} and Dv^{-0.5}
        du = sum(G);  
        Du = spdiags(1./sqrt(du),0,n_va,n_va);
        dv = max(sum(G,2),1e-5);  
        Dv = spdiags(1./sqrt(dv),0,2*m,2*m);
        
        DGD = Du*sparse(G')*Dv;
        
        [FU,~,FV] = svds(DGD,numclass);
        
        Fu = sqrt(2)*FU/2;
        Fv = sqrt(2)*FV/2;


        obj(iter) = sum(sum((X-A*Z).^2))+sum(sum((B-S).^2)) + alpha*sum(sum((S(:,idx_a)-S_last(:,idx_a)).^2)) - lambda* trace(Fu'*DGD*Fv);
        if (iter>2) && (abs((obj(iter)-obj(iter-1))/(obj(iter)))<epson  || iter>maxIter)
            Isconverg  =1;
        end
            iter = iter + 1;
end

F=[Fu;Fv];

end
